/*******************************************************************************
 * @author Reika Kalseki
 * 
 * Copyright 2017
 * 
 * All rights reserved.
 * Distribution of the software in any form is only allowed with
 * explicit, prior permission from the owner.
 ******************************************************************************/
package Reika.RotaryCraft.GUIs.Machine;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;

import Reika.RotaryCraft.Base.GuiPowerOnlyMachine;
import Reika.RotaryCraft.Containers.Machine.ContainerSorter;
import Reika.RotaryCraft.TileEntities.TileEntitySorting;

public class GuiSorter extends GuiPowerOnlyMachine {

	private TileEntitySorting tile;

	public GuiSorter(EntityPlayer player, TileEntitySorting te) {
		super(new ContainerSorter(player, te), te);
		tile = te;
		xSize = 176;
		ySize = 180;
		ep = player;
	}

	@Override
	protected void drawGuiContainerForegroundLayer(int a, int b)
	{
		super.drawGuiContainerForegroundLayer(a, b);
		int dy = 22;
		int x = 8;
		int y = 18;
		int l = tile.LENGTH;
		for (int k = 0; k < l*3; k++) {
			ItemStack is = tile.getMapping(k);
			if (is != null) {
				api.drawItemStack(itemRender, fontRendererObj, is, x+k%l*18, y+k/l*dy);
			}
		}
	}

	@Override
	protected String getGuiTexture() {
		return "sortergui";
	}

}
